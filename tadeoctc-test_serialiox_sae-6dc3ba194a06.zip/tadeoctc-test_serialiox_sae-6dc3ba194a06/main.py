from flask import Flask, jsonify, render_template, make_response,request
from codetx.Monitor import MonitorMsjGeo
from codetx.Mensajes import MensajesSerialIOX
from codetx.Login import Login
import re


app = Flask(__name__)
mensajes = MensajesSerialIOX()
oLogin = Login()
@app.route('/')
def index():
    return render_template('index_evo.html')

@app.route('/sae')
def index_evo():
    return render_template('index.html')

@app.route('/login',methods=['POST'])
def login():
    if 'user' in request.form:
        if oLogin.isAuthorized(request.form['user']):
            return jsonify( { 'valid': 'ok' } )
        else:
            return  make_response(jsonify({'error': 'ERROR C102'}), 403)    
    else:
        return  make_response(jsonify({'error': 'ERROR C101'}), 500)


@app.route('/loginTest')
def loginTest():
    return render_template('login.html')

@app.route('/devices', methods=['POST'])
def devices():
    return jsonify(mensajes.getDevices())

@app.route('/info',methods=['POST'])
def info_bus():
    if 'unidad' in request.form:
        try:
            return jsonify( sorted( mensajes.getTextMessages(bus=request.form['unidad'],minutos=3000).items(), key=lambda kv: kv[1]['enviado'], reverse=True) )
        except:
            return  make_response(jsonify({'error': 'ERROR A102'}), 500)    
    else:
        return  make_response(jsonify({'error': 'ERROR A101'}), 500) 


@app.route('/newMsj',methods=['POST'])
def show_user_profile():
    if 'nMensaje' in request.form and len(request.form['nMensaje']) <= 0:
        return  make_response(jsonify({'error': 'ERROR B102'}), 500)
    elif 'nMensaje' in request.form and len(request.form['nMensaje']) > 50:
        return  make_response(jsonify({'error': 'ERROR B103'}), 500)
    elif 'unidad' in request.form and request.form['unidad'] == '0':
        #TODO: Validar con expresiones regulares la unidad, también el método info_bus()
        return  make_response(jsonify({'error': 'ERROR B101'}), 500) 
    elif 'unidad' in request.form and 'nMensaje' in request.form:
        return jsonify(mensajes.sendTextMessage(request.form['nMensaje'], request.form['unidad'],'b9'))
    else:
        return  make_response(jsonify({'error': 'ERROR B100'}), 500) 

#Manejo de Errores HTTP
@app.errorhandler(404)
def page_not_foud(error):
    return "I'm afraid, the page isn't exists!", 404

@app.errorhandler(405)
def page_405(error):
    return "Stop, it's forbidden!", 405

@app.errorhandler(500)
def page_500(error):
    return  make_response(jsonify({'error': 'Oops 500!'}), 500)
    #return 'Oops!, 500!'

@app.errorhandler(502)
def page_502(error):
    return  make_response(jsonify({'error': 'Oops 502!'}), 502)

#Fin de manejo de Errores HTTP

#NO CACHE
@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    '''
    r.headers['Cache-Control'] = 'public, max-age=60, s-maxage=60, must-revalidate'
    r.headers['X-Robots-Tag'] = 'none'
    '''
    return r


if __name__ == "__main__":
    @app.route('/test')
    def index2():
        return render_template('index_test.html')
    app.config['ENV'] = 'development'
    app.run('0.0.0.0',port=3001,debug=True)