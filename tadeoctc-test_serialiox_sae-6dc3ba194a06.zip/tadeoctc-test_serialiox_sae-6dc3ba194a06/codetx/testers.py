import datetime
import timedelta
#from dateutil import tz

if __name__ == '__main__':
    thisdict = {
        "brand" : {
            "att1" : "v1",
            "att2" : "v2"
        },
        "model" : "Mustang",
        "year" : 1964
    }

    diccionario2 = {}

    thisdict['model'] = {
        "attr1" : "v3",
        "attr2" : "v4"
    }

    thisdict['nuevo'] = {
        "solo" : "asi",
        "puedes" : "ver",
        "numero" : 0
    }

    thisdict['nuevo']['numero']+=5

    diccionario2['favorita'] = {
        "Artista" : "Camilo VII",
        "Álbum" : "Óleos",
        "Pista" : "Fusión",
        "otro" : None
    }

    print(thisdict['brand'])
    print(thisdict['model'])
    print(thisdict['nuevo'])
    print(diccionario2)

    hoy = datetime.date.today()
    ahora = datetime.datetime.now()
    #ayer = hoy - 1

    print(str(datetime.date.today()) + 'T05:00:00')
    print(ahora)
    print(str(ahora)[0:19].replace(' ','T'))

    c = 0
    for ax in thisdict:
        if c >= 2:
            break
        else: 
            print(ax)
            c+=1

    ahoraUTC = datetime.datetime.today() + timedelta.Timedelta(hours=5)
    print (ahoraUTC)

    _antes24 = str(datetime.date.today() - timedelta.Timedelta(days=1)) + str(str(datetime.datetime.today())[10:16])
    _antes24 =str(datetime.datetime.today() - timedelta.Timedelta(hours=((1*24)-5)))[0:19].replace(' ','T')
    print(_antes24)
    '''
    #Comentado porque no se requiere en el backend
    print(str(datetime.date.today() - timedelta.Timedelta(days=0)))
    to_zone = tz.gettz('Mexico/General')
    #utc = datetime.datetime.utcnow()
    #print('UTC: ' + str(utc))
    #utc = (datetime.datetime.utcnow()).replace(tzinfo=tz.tzutc())
    #print('UTC2: ' + str(utc))
    local = ( (datetime.datetime.utcnow()).replace(tzinfo=tz.tzutc()) ).astimezone(to_zone)
    print('Local: ' + str(local) + ' - ' + str(local.date()) )
    #local2 = 
    print(tz.gettz('Mexico/General'))
    '''

    #'fromDate' : str(datetime.date.today()) + 'T05:00:00'