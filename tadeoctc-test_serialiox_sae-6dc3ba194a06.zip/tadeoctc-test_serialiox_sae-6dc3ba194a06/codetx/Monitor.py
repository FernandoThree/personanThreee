import requests
import json
import datetime
import timedelta
import sys
from codetx.Acceso import Acceso

class MonitorMsjGeo:

    def getDiccionario(self,diasAtras = 1):
        ahora = datetime.datetime.utcnow()
        myAcceso = Acceso()
        #grupoID = None
        reqDevices = { 
            'method' : 'Get', 
            'params': {
                'typeName':'Device', 
                'credentials': myAcceso.getCrede()
            }
        }
        diccionario = {}
        resume = {'verde':0,'negro' : 0, 'gris' : 0,'azul' : 0,'morado' : 0, 'rojo' : 0, 'naranja' : 0,'amarillo' : 0, 'total':0}
        totalB = 0
        respDevices = myAcceso.getElement(reqDevices)
        if respDevices.status_code == 200:
            if 'error' in respDevices.json():
                print(respDevices.json(), file=sys.stderr)
                return None
            else:
                for x in respDevices.json()['result']:
                    if x['devicePlans'] is not None and len(x['devicePlans']) > 0 and x['serialNumber'] != '000-000-0000':
                        totalB += 1
                        diccionario[x['id']] = { 
                            "eco": x['name'],
                            "nRecibidos" : 0,
                            "sRecibidos" : 0,
                           "bRecibidos" : 0,
                            "fechorUltimoRecibido" : None,
                            "fechorUltimoEnviado" : None,
                            "fechorUltimoTransp": None,
                            "alerta" : "N/D",
                            "diasSinConexion" : None,
                            "fechaUltConexion" : None
                        }
            resume['total'] = totalB
            #Inicio Status Info    
            reqLg = { 
                'method' : 'Get', 
                'params': {
                    'typeName':'DeviceStatusInfo', 
                    'credentials': myAcceso.getCrede()
                }
            }
            respLg = myAcceso.getElement(reqLg)
            if respLg.status_code == 200:
                if 'error' in respLg.json():
                    print(respLg.json(), file=sys.stderr)
                    return diccionario
                for stDev in respLg.json()['result']:
                    diccionario[stDev['device']['id']]['diasSinConexion']=(ahora - datetime.datetime.strptime(stDev['dateTime'], '%Y-%m-%dT%H:%M:%S.%fZ')).days
                    diccionario[stDev['device']['id']]['diasSinConexion'] = diccionario[stDev['device']['id']]['diasSinConexion'] if diccionario[stDev['device']['id']]['diasSinConexion'] > 0 else 0
                    diccionario[stDev['device']['id']]['fechaUltConexion']=stDev['dateTime']
                    if 'latitude' in stDev and 'longitude' in stDev:
                        diccionario[stDev['device']['id']]['lat'] = stDev['latitude']
                        diccionario[stDev['device']['id']]['lon'] = stDev['longitude']
            del respLg
            #Fin Status Info 
            reqMsj = { 
                'method' : 'Get', 
                'params': {
                    'typeName':'TextMessage', 
                    'search' :  {
                        'fromDate' :  str(datetime.datetime.today() - timedelta.Timedelta(hours=((diasAtras*24)-5)))[0:19].replace(' ','T')
                    },
                    'credentials': myAcceso.getCrede()
                }
            }
            respMensj = myAcceso.getElement(reqMsj)
            if respMensj.status_code == 200:
                if 'error' in respMensj.json():
                    print(respMensj.json())
                    return diccionario
                #nRecibidos => #Mensajes NO RECIBIDOS de SERVER -> BUS
                #sRecibidos => #Mensajes SI RECIBIDOS de SERVER -> BUS
                #bRecibidos => Mensajes DEL BUS -> SERVER
                for msj in respMensj.json()['result']:
                    if "delivered" in msj:
                        if msj['isDirectionToVehicle']:
                            diccionario[msj['device']['id']]['sRecibidos']+=1
                            if diccionario[msj['device']['id']]['fechorUltimoRecibido'] is None or diccionario[msj['device']['id']]['fechorUltimoRecibido'] < msj['sent']:
                                diccionario[msj['device']['id']]['fechorUltimoRecibido'] = msj['sent']
                        else:
                            diccionario[msj['device']['id']]['bRecibidos']+=1
                            if diccionario[msj['device']['id']]['fechorUltimoTransp'] is None or diccionario[msj['device']['id']]['fechorUltimoTransp'] < msj['sent']:
                                diccionario[msj['device']['id']]['fechorUltimoTransp'] = msj['sent']
                    else:
                        diccionario[msj['device']['id']]['nRecibidos']+=1
                        if diccionario[msj['device']['id']]['fechorUltimoEnviado'] is None or diccionario[msj['device']['id']]['fechorUltimoEnviado'] < msj['sent']:
                            diccionario[msj['device']['id']]['fechorUltimoEnviado'] = msj['sent']
                indicador = 30
                revisarHist = []
                for palabra in diccionario:
                    if diccionario[palabra]['diasSinConexion'] > 3:
                        #Sin comunicaciOn por mAs de 3 dIas
                        diccionario[palabra]['alerta'] = 'negro'
                        resume['negro'] +=1
                    elif diccionario[palabra]['nRecibidos'] + diccionario[palabra]['sRecibidos'] == 0:
                        #Sin actividad en el dIa
                        diccionario[palabra]['alerta'] = 'gris'
                        resume['gris'] +=1
                    elif diccionario[palabra]['nRecibidos'] + diccionario[palabra]['sRecibidos'] < indicador:
                        #Poca informaciOn para dar un diagnOstico
                        diccionario[palabra]['alerta'] = 'azul'
                        resume['azul'] +=1
                        revisarHist.append(palabra)
                    elif diccionario[palabra]['nRecibidos'] > indicador and diccionario[palabra]['bRecibidos'] > 0 and (ahora - (datetime.datetime.strptime(diccionario[palabra]['fechorUltimoTransp'], '%Y-%m-%dT%H:%M:%S.%fZ'))).seconds < 2700:
                        #Bus en recuperaciOn, mAs mensajes no recibidos pero con mensajes de transponder menores a 45 min
                        diccionario[palabra]['alerta'] = 'morado'
                        resume['morado'] +=1
                        #print(diccionario[palabra])
                    elif diccionario[palabra]['nRecibidos'] > indicador and (diccionario[palabra]['bRecibidos'] == 0 or (ahora - (datetime.datetime.strptime(diccionario[palabra]['fechorUltimoTransp'], '%Y-%m-%dT%H:%M:%S.%fZ'))).seconds >= 2700):
                        #Autobus sin comunicaciOn
                        diccionario[palabra]['alerta'] = 'rojo'
                        resume['rojo'] +=1
                        if diccionario[palabra]['sRecibidos'] == 0:
                            revisarHist.append(palabra)
                            #print(diccionario[palabra])
                    elif diccionario[palabra]['bRecibidos'] == 0:
                        if diccionario[palabra]['sRecibidos'] > indicador:
                            #AutobUs que recibe mensajes pero no envIa
                            diccionario[palabra]['alerta'] = 'naranja'
                            resume['naranja'] +=1
                        else:
                            #Poca informaciOn para dar un diagnOstico, ya que puede ir saliendo la unidad y no enviO transpondedor por seNYal.
                            diccionario[palabra]['alerta']='azul'
                            resume['azul'] +=1
                    elif diccionario[palabra]['nRecibidos'] >= 10 and diccionario[palabra]['nRecibidos'] <= indicador:
                        #AutobUs que empieza a perder comunicaciOn
                        diccionario[palabra]['alerta']='amarillo'
                        resume['amarillo'] +=1
                    else:
                        #AutobUs funcionando correctamente
                        diccionario[palabra]['alerta']='verde'
                        resume['verde']+=1
        del respMensj
        diccionario['resume'] = resume
        return diccionario
