$().ready(function(){

    var _dataDevices = {};
    var _sending = false;
    var _loadingMsg = false;
    var _isvalid = false;
    $('.divLogout').hide();

    function userValid(){
        var _isvalid = false;
        $.ajax({
            'url' : '/login',
            'method' : 'POST',
            'async' : 'false',
            'data' : $('#f2').serialize(),
            success: function(response){
                _isvalid= true;
                $('.divLogout').css('margin-top','0px');
                $('.divNoAut').hide();
                iniciar();
                $('.divLogout').show();
            },
            statusCode:{
                500: function(responseError){
                    $('.titPrin').html(responseError['responseJSON']['error']);
                    $('.divNoAut').show();
                    $('.divLogout').show();
                },
                403: function(responseError){
                    $('.titPrin').html('-');
                    $('.divNoAut').css('margin-top','80px');
                    $('.divNoAut').show();
                    $('.divLogout').show();
                }
            }
        });  
        return _isvalid; 
    }

    function fechas(_fecha){
        if(_fecha == undefined){
            return "N/D";
        }else{
            var mili = Date.parse(_fecha);
            var d = new Date(mili);
            d = new Date(d)
            return d.toLocaleString();
        }
    }

    function setLblLastLoad(){
        $('#lblLastLoad').html(new Date(Date.now()).toLocaleString());
    }

    function getDevices(){
        $.ajax({
            'url' : '/devices',
            'method' : 'POST',
            'async' : 'true',
            success: function(response){
                _dataDevices = response;
                var _nSelect = "<option value=\"0\" default>Unidad</option>";
                for(var key in response){
                    _nSelect += '<option value="'+key+'">'+ response[key]['eco'] +'</option>';
                }
                $('#unidad').html(_nSelect);
                $('.titPrin').html('Ready!');
                setLblLastLoad();
            },
            statusCode:{
                500: function(responseError){
                    $('.titPrin').html(responseError['responseJSON']['error']);
                }
            }
        });
    }
    

    function hideAll(){
        $('.detail').hide();
    }

    $('.imgBtn').hover(function(){
        $(this).attr('src',$(this).attr('src').replace('.png','_hover.png'));
    },function(){
        $(this).attr('src',$(this).attr('src').replace('_hover.png','.png'));
    });

    $('#unidad').change(function(){
        if($(this).val() == 0 || _dataDevices[$(this).val()] == undefined){
            $('.serie').html('N/D');
        }else{
            //
            $('#msjLst').html('');
            $('.serie').html(_dataDevices[$(this).val()]['serialNumber']);
        }
    });

    $('#btnShowMap').click(function(){
        if ($('#unidad').val() == 0 || _dataDevices[$('#unidad').val()]['lat'] == undefined || _dataDevices[$('#unidad').val()]['lon'] == undefined){
            alert('Ubicación NO DISPONIBLE');
        }else{
            window.open('https://www.google.com/maps/search/'+ _dataDevices[$('#unidad').val()]['lat'] +',+'+ _dataDevices[$('#unidad').val()]['lon'] +'/@'+ _dataDevices[$('#unidad').val()]['lat'] +','+ _dataDevices[$('#unidad').val()]['lon'] +',17z','_blank');
        }
    });

    $('#btnNewMsg').click(function(){
        $('.panelNvoMsj').show();
    });

    $('#btnReloadMsg').click(function(){
        if (!_loadingMsg){
            if( $('#unidad').val() == 0 ){
                alert('Elija una unidad');
            }else{
                _loadingMsg=true;
                $('.titPrin').html('Loading...');
                $.ajax({
                    'url' : '/info',
                    'method' : 'POST',
                    'async' : 'true',
                    'data' : $('#f1').serialize(),
                    success: function(response){
                        var _nListaMensajes = "";
                        $(response).each(function(i,e){
                            _nListaMensajes += '<div class="listaDivItem '+ (e[1].toDevice ? 'der' : 'izq') +'"><div><div class="imageListMsj"><div class="divImgPng"><img class="pngMsjSt" src="/static/img/msj_en'+ (e[1].estado == "ok" ? 'viado' : '_proceso') +'.png" alt="Bus"></div></div><div class="textoListMsj"><p class="pMsjText">'+e[1].msj +'</p></div></div><div class="detMsg"><div class="imageListMsj"><div class="divImgPng"><img class="pngDetMsg" src="/static/img/enviado.png" alt="Enviado"></div></div><div class="textoListMsj"><p class="pDetMsg">'+ fechas(e[1].enviado) +'</p></div></div><div class="detMsg"><div class="imageListMsj"><div class="divImgPng"><img class="pngDetMsg" src="/static/img/recibido.png" alt="Recibido"></div></div><div class="textoListMsj"><p class="pDetMsg">'+ fechas(e[1].entregado) +'</p></div></div></div>';
                        });
                        $('#msjLst').html(_nListaMensajes);
                        $('#msjLst').show();
                        $('.titPrin').html('Ready!');

                        $('.listaDivItem').each(function(){
                            $(this).click(function(){
                                $(this).children('.detMsg').toggle();
                                if($(this).children('.detMsg').css('display') == "none"){
                                    $(this).css('height','40px');
                                }else{
                                    $(this).css('height','90px');
                                }                                
                            });
                        });

                        _loadingMsg = false;
                        setLblLastLoad();
                    },
                    statusCode:{
                        500: function(responseError){
                            $('.titPrin').html(responseError['responseJSON']['error']);
                            $('#msjLst').html('');
                            _loadingMsg = false;
                        }
                    }
                });
            }
        }
    });

    $('#send').click(function(){
        if( !_sending){
            if( $('#unidad').val() == 0 ){
                alert('Elija una unidad');
            }else if($('#nMensaje').val().length <= 0){
                alert('Por favor escriba un mensaje');
            }else if($('#nMensaje').val().length > 50){
                alert('Mensaje máximo 50 caracteres')
            }else{
                _sending = true;
                $('.titPrin').html('Sending...');
                $.ajax({
                    'url' : '/newMsj',
                    'method' : 'POST',
                    'async' : 'true',
                    'data' : $('#f1').serialize(),
                    success: function(response){
                        if( response['result'] != undefined){
                            $('.titPrin').html('Ready!');
                            $('.panelNvoMsj').hide();
                            $('#nMensaje').val('');
                            _sending = false;
                            setLblLastLoad();
                        }
                    },statusCode:{
                        500: function(responseError){
                            $('.titPrin').html(responseError['responseJSON']['error']);
                            _sending = false;
                        }
                    }
                });
            }
        }
    });

    $('#cancel').click(function(){
        $('.panelNvoMsj').hide();
        $('#nMensaje').val('');
    });

    function iniciar(){
        getDevices();
        $('#sender').show();
    }

     ///////////START LOGIN/////////////

        //Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBRiNfnIb_XN9XrCu1dfAYUR-0htuboXCU",
            authDomain: "proy-vsp-sae-v1-deploy-test-v1.firebaseapp.com",
            databaseURL: "https://proy-vsp-sae-v1-deploy-test-v1.firebaseio.com",
            projectId: "proy-vsp-sae-v1-deploy-test-v1",
            storageBucket: "proy-vsp-sae-v1-deploy-test-v1.appspot.com",
            messagingSenderId: "331093985273",
            appId: "1:331093985273:web:22ae77b94c0aac09895f28"
        }
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);

        // Listening for auth state changes.
        // [START authstatelistener]
        //alert(user);
        firebase.auth().onAuthStateChanged(function(user) {
            if (user) {
                $('#user').val(user.email);
                userValid();
            } else {
                // User is signed out.
                $('#user').val('x');
                var provider = new firebase.auth.GoogleAuthProvider();
                firebase.auth().signInWithRedirect(provider);
            }
        });

        
        $('#closeSession').click(function(){
            firebase.auth().signOut();
        });
        


    ////////////END LOGIN/////////////

});