﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class Form1 : Form
    {
        OpenConnection OpenSql = new OpenConnection();
        public Form1()
        {
            InitializeComponent();
            label1.Text = ("Data Source = 10.15.5.102; User ID = usrSAE; Password = xel}}'Dexir; Initial Catalog=CEN_EVOLIA_SAE; Connect Timeout=60");
            label1.AutoSize = true;
            btnmCloseConnection.Text = "Encriptar Cadena";
            btnTestConnection.Text = "Desencriptar cadena";
        }

        string encriptar(string cadenaConn)
        {
            string resultado = string.Empty;
            Byte[] encriptar = System.Text.Encoding.Unicode.GetBytes(cadenaConn);
            resultado = Convert.ToBase64String(encriptar);

            return resultado;
        }

        string desencriptar(string connCadena)
        {
            string resultado = string.Empty;
            byte[] desenCriptar = Convert.FromBase64String(connCadena);

            resultado = System.Text.Encoding.Unicode.GetString(desenCriptar);
            return resultado;
        }
        private void btnTestConnection_Click(object sender, EventArgs e)
        {
            UsingRsaProtectedConfigurationProvider.Main("protect, unprotect");
            //dataGridView1.DataSource = OpenSql.SelectDataTable("select * from salida_autobus");
            string DconnString = desencriptar(textBox1.Text);
            MessageBox.Show(DconnString);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnmCloseConnection_Click(object sender, EventArgs e)
        {
            string connectString = encriptar("Data Source= 10.15.5.102; User ID=usrSAE; Password=xel}}'Dexir; Initial Catalog=CEN_EVOLIA_SAE; Connect Timeout=60");
            textBox1.Text = connectString;

            MessageBox.Show(connectString);
            btnTestConnection.Enabled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
